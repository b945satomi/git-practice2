# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'd4953808aff9b2a7bc907870a2aa5b561761de32daa38a0a026b278f75fdca00892336fc3cd0e9ed97e81830af9c867baa512eee12d8c2b443f66fb18aa3934b'