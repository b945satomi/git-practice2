class BooksController < ApplicationController

  def create
    @bookNew = Book.new(book_params)
    @bookNew.user_id = current_user.id
    if @bookNew.save
      flash[:notice] = "You have created book successfully."
      redirect_to book_path(@bookNew.id)
    else
      @user = User.find(current_user.id)
      @books = Book.all.page(params[:page]).per(10)
      flash.now[:danger] = @bookNew.errors.full_messages
      render :index
    end
  end

  def index
    @user = User.find(current_user.id)
    @bookNew = Book.new
    @books = Book.all.page(params[:page]).per(10)
  end

  def show
    @user = User.find(current_user.id)
    @bookNew = Book.new
    @book = Book.find(params[:id])
    @bookUser = User.find(@book.user_id)
  end

  def edit
    @book = Book.find(params[:id])
    if @book.user_id == current_user.id
      render "edit"
    else
      redirect_to books_path
    end
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
      flash[:notice] = "You have updated book successfully."
      redirect_to book_path(@book.id)
    else
      flash.now[:danger] = @book.errors.full_messages
      render :edit
    end
  end

  def destroy
    @book = Book.find(params[:id])
    @book.destroy
    redirect_to books_path
  end

#########################################################
  private

  def book_params
    params.require(:book).permit(:title, :body)
  end


end
