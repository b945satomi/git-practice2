class RenameImageIdToProfileImageIdInUsers < ActiveRecord::Migration[5.2]
  def up
    rename_column :users, :image_id, :profile_image_id
  end

  def down
    rename_column :users, :profile_image_id, :image_id
  end
end
