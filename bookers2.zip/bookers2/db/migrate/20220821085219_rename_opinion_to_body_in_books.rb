class RenameOpinionToBodyInBooks < ActiveRecord::Migration[5.2]
  def up
    rename_column :books, :opinion, :body
  end

  def down
    rename_column :books, :body, :opinion
  end
end
